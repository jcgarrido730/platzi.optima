package viewmodel

const (
	CompareSingleLayer LayerCompareMode = iota
	CompareAllLayers
)

type LayerCompareMode int
