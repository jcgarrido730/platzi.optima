package view

import "github.com/wagoodman/dive/runtime/ui/viewmodel"

type LayerChangeListener func(viewmodel.LayerSelection) error
