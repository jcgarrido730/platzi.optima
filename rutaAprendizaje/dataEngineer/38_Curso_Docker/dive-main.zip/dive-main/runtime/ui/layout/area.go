package layout

type Area struct {
	minX, minY, maxX, maxY int
}
