package layout

const (
	LocationFooter Location = iota
	LocationHeader
	LocationColumn
)

type Location int
