#!/usr/bin/env bash
trap 'exit 0' SIGTERM
while true; do :; done
